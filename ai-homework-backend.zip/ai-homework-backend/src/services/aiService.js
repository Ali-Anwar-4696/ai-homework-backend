const axios = require('axios');

const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';

const solveQuestion = async (question, subject) => {
  try {
    const prompt = `
You are an expert AI tutor. Solve the following ${subject} problem step-by-step.

Question:
${question}

Rules:
- Give clear step-by-step solution
- Keep explanation simple
- If theory question → explain clearly
- If math → show steps

Return ONLY valid JSON:
{
  "answer": "final answer",
  "steps": ["step 1", "step 2"],
  "explanation": "simple explanation"
}`;

    const response = await axios.post(
      OPENROUTER_API_URL,
      {
        model: 'deepseek/deepseek-r1:free',
        messages: [{ role: 'user', content: prompt }],
        response_format: { type: 'json_object' }
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.API_KEY}`,
          'Content-Type': 'application/json'
        },
        timeout: 45000 // Increased timeout for DeepSeek
      }
    );

    const aiContent = response.data.choices[0].message.content;

    // Safe JSON Parsing Logic
    try {
      return JSON.parse(aiContent);
    } catch (e) {
      console.warn('AI returned invalid JSON, falling back to raw response.');
      return {
        answer: aiContent,
        steps: [],
        explanation: "AI response could not be structured, showing raw output.",
        source: "ai"
      };
    }
  } catch (error) {
    console.error('AI Service Error:', error.message);
    throw new Error('Failed to reach AI service properly.');
  }
};

module.exports = {
  solveQuestion
};
