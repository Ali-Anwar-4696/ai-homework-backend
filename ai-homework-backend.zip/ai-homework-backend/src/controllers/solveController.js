const { solveQuestion } = require('../services/aiService');

const handleSolveRequest = async (req, res, next) => {
  const { question, subject } = req.body;

  if (!question || !subject) {
    return res.status(400).json({
      error: "Invalid input",
      message: "Both question and subject are required."
    });
  }

  try {
    const solution = await solveQuestion(question, subject);
    
    // The response schema matches EXACTLY what the user requested:
    // { "answer": "string", "steps": [], "explanation": "string", "source": "ai" }
    res.json({
      answer: solution.answer || "No answer provided",
      steps: solution.steps || [],
      explanation: solution.explanation || "No explanation provided",
      source: "ai"
    });
  } catch (error) {
    console.error('Solve Controller Error:', error.message);
    
    // Handle specific errors from aiService or propagate to error handler middleware
    if (error.message.includes('AI Service')) {
      return res.status(503).json({
        error: "AI Service Failure",
        message: error.message
      });
    }

    // Default error response for solving process
    res.status(500).json({
      error: "Internal Server Error",
      message: "An error occurred while processing your request. Please try again."
    });
  }
};

module.exports = {
  handleSolveRequest
};
