const express = require('express');
const cors = require('cors');
const solveRoutes = require('./routes/solveRoutes');

const app = express();

// Basic Middleware
app.use(cors());
app.use(express.json());

// Health Check Route (Required for Render/Deployment)
app.get("/", (req, res) => {
  res.send("AI Homework Backend is running 🚀");
});

// Security Middleware (API Key Check)
app.use((req, res, next) => {
  const key = req.headers["x-app-key"];
  
  // Use environment variable for security
  if (key !== process.env.APP_SECRET_KEY) {
    return res.status(403).json({ error: "Unauthorized" });
  }
  next();
});

// Routes
app.use('/api', solveRoutes);

// Detailed Error Handling Middleware
app.use((err, req, res, next) => {
  console.error('Unhandled Error:', err.stack);
  res.status(500).json({
    error: "Internal Server Error",
    message: err.message || "An unexpected error occurred."
  });
});

module.exports = app;
