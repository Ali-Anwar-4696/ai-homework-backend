const express = require('express');
const router = express.Router();
const { handleSolveRequest } = require('../controllers/solveController');
const rateLimiter = require('../middleware/rateLimiter');

// Apply rate limiter specifically to the solve route
router.post('/solve', rateLimiter, handleSolveRequest);

module.exports = router;
