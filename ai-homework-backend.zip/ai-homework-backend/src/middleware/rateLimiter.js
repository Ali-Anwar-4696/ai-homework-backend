// In-memory storage for rate limiting
// For production with multiple instances, use Redis
const userLimits = new Map();

const RATE_LIMIT = 10; // requests per user
const RESET_INTERVAL = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

const rateLimiter = (req, res, next) => {
  // Enhanced IP detection for proxies (Render, Cloudflare, etc.)
  const userId = req.headers['x-forwarded-for'] || req.ip || 'unknown';
  const currentTime = Date.now();

  let userData = userLimits.get(userId);

  if (!userData) {
    // First request from this user
    userData = {
      count: 1,
      resetTime: currentTime + RESET_INTERVAL
    };
    userLimits.set(userId, userData);
    return next();
  }

  // Check if reset time has passed
  if (currentTime > userData.resetTime) {
    userData.count = 1;
    userData.resetTime = currentTime + RESET_INTERVAL;
    return next();
  }

  // Check if limit reached
  if (userData.count >= RATE_LIMIT) {
    return res.status(429).json({
      error: "Daily limit reached",
      message: "You have used your 10 free daily requests. Please try again tomorrow."
    });
  }

  // Increment count
  userData.count++;
  next();
};

module.exports = rateLimiter;
